package jassd.model;

import java.util.Date;

public class UserCars {
  private int usercarId;
  private int userId;
  private int carId;
  private String licensePlate;
  private long kilometers;
  
  public int getUsercarId() {
    return usercarId;
  }
  public void setUsercarId(int usercarId) {
    this.usercarId = usercarId;
  }
  public int getUserId() {
    return userId;
  }
  public void setUserId(int userId) {
    this.userId = userId;
  }
  public int getCarId() {
    return carId;
  }
  public void setCarId(int carId) {
    this.carId = carId;
  }
  public String getLicensePlate() {
    return licensePlate;
  }
  public void setLicensePlate(String licensePlate) {
    this.licensePlate = licensePlate;
  }
  public long getKilometers() {
    return kilometers;
  }
  public void setKilometers(long kilometers) {
    this.kilometers = kilometers;
  }
}

