package jassd.model;

import java.util.Date;

public class Car {
  private int carId;
  private String make;
  private String model;
  private int year;
  private double price;
  private float rating;
  private String vin;
  
  public int getCarId() {
    return carId;
  }
  public void setCarId(int carId) {
    this.carId = carId;
  }
  public String getMake() {
    return make;
  }
  public void setMake(String make) {
    this.make = make;
  }
  public String getModel() {
    return model;
  }
  public void setModel(String model) {
    this.model = model;
  }
  public int getYear() {
    return year;
  }
  public void setYear(int year) {
    this.year = year;
  }
  public double getPrice() {
    return price;
  }
  public void setPrice(double price) {
    this.price = price;
  }
  public float getRating() {
    return rating;
  }
  public void setRating(float rating) {
    this.rating = rating;
  }
  public String getVin() {
    return vin;
  }
  public void setVin(String vin) {
    this.vin = vin;
  }
}
