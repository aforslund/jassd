package jassd.controller;

import jassd.dao.*;
import jassd.model.*;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/jassd")
public class JassdController {
  @Autowired
  private JassdDao jassdDao;
  @RequestMapping("cars")
  @ResponseBody
  public List<Car> getCars() {
    return jassdDao.getCars();
  }
  @RequestMapping("users")
  @ResponseBody
  public List<User> getUsers() {
    return jassdDao.getUsers();
  }
  @RequestMapping("usercars")
  @ResponseBody
  public List<UserCars> getUserCars() {
    return jassdDao.getUserCars();
  }
}
