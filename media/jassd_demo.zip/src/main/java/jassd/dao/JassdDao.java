package jassd.dao;

import java.util.List;
import jassd.model.*;

public interface JassdDao {
  public List<Car> getCars();
  public void createCar(Car car);
  public void updateCar(Car car);
  public Car getCarById(int carId);
  public List<User> getUsers();
  public void createUser(User user);
  public void updateUser(User user);
  public User getUserById(int userId);
  public List<UserCars> getUserCars();
  public void createUserCars(UserCars usercars);
  public void updateUserCars(UserCars usercars);
  public UserCars getUserCarsById(int usercarId);
}

