package jassd.dao.impl;

import java.util.List;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;
import java.util.Map;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import java.sql.ResultSet;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import jassd.dao.*;
import jassd.model.*;

@Component("JassdDao")
public class JassdDaoImpl implements JassdDao {

  private JdbcTemplate jdbcTemplate;
  private NamedParameterJdbcTemplate namedJdbcTemplate;

  @Autowired
  private void setDataSource(DataSource dataSource) {
    jdbcTemplate = new JdbcTemplate(dataSource);
    namedJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
  }

  @Override
  public List<Car> getCars() {
    return jdbcTemplate.query("SELECT * FROM car", new CarExtractor());
  }
  @Override
  public void createCar(Car car) {
    KeyHolder keyHolder = new GeneratedKeyHolder();
    jdbcTemplate.update(new CarCreator(car), keyHolder);
    car.setCarId(keyHolder.getKey().intValue());
  }
  @Override
  public void updateCar(Car car) {
    jdbcTemplate.update(new CarUpdater(car));
  }
  @Override
  public Car getCarById(int carId) {
    Map namedParameters = Collections.singletonMap("carId", carId);
    return namedJdbcTemplate.queryForObject("SELECT * FROM car WHERE car_id=:carId", namedParameters, new CarExtractor());
  }
  private class CarCreator implements PreparedStatementCreator {
    private Car car;
    public CarCreator(Car car) {
      this.car = car;
    }
    @Override
    public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
      PreparedStatement ps = connection.prepareStatement(
            "INSERT INTO car (make, model, year, price, rating, vin) "
      + "VALUES (?, ?, ?, ?, ?, ?) ", Statement.RETURN_GENERATED_KEYS);
      ps.setString(1, car.getMake());
      ps.setString(2, car.getModel());
      ps.setInt(3, car.getYear());
      ps.setString(4, car.getVin());
      return ps;
    }
  }
  private class CarUpdater implements PreparedStatementCreator {
    private Car car;
    public CarUpdater(Car car) {
      this.car = car;
    }
    @Override
    public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
      PreparedStatement ps = connection.prepareStatement(
            "UPDATE car SET make=?, model=?, year=?, price=?, rating=?, vin=? WHERE car_id=?");
      ps.setString(1, car.getMake());
      ps.setString(2, car.getModel());
      ps.setInt(3, car.getYear());
      ps.setDouble(4, car.getPrice());
      ps.setFloat(5, car.getRating());
      ps.setString(6, car.getVin());
      ps.setInt(7, car.getCarId());
      return ps;
    }
  }
  private class CarExtractor implements RowMapper<Car> {
    @Override
    public Car mapRow(ResultSet rs, int i) throws SQLException {
      Car c = new Car();
      c.setCarId(rs.getInt("car_id"));
      c.setMake(rs.getString("make"));
      c.setModel(rs.getString("model"));
      c.setYear(rs.getInt("year"));
      c.setPrice(rs.getDouble("price"));
      c.setRating(rs.getFloat("rating"));
      c.setVin(rs.getString("vin"));
      return c;
    }
  }
  @Override
  public List<User> getUsers() {
    return jdbcTemplate.query("SELECT * FROM user", new UserExtractor());
  }
  @Override
  public void createUser(User user) {
    KeyHolder keyHolder = new GeneratedKeyHolder();
    jdbcTemplate.update(new UserCreator(user), keyHolder);
    user.setUserId(keyHolder.getKey().intValue());
  }
  @Override
  public void updateUser(User user) {
    jdbcTemplate.update(new UserUpdater(user));
  }
  @Override
  public User getUserById(int userId) {
    Map namedParameters = Collections.singletonMap("userId", userId);
    return namedJdbcTemplate.queryForObject("SELECT * FROM user WHERE user_id=:userId", namedParameters, new UserExtractor());
  }
  private class UserCreator implements PreparedStatementCreator {
    private User user;
    public UserCreator(User user) {
      this.user = user;
    }
    @Override
    public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
      PreparedStatement ps = connection.prepareStatement(
            "INSERT INTO user (name, email, date_of_birth, active) "
      + "VALUES (?, ?, now(), ?) ", Statement.RETURN_GENERATED_KEYS);
      ps.setString(1, user.getName());
      ps.setString(2, user.getEmail());
      return ps;
    }
  }
  private class UserUpdater implements PreparedStatementCreator {
    private User user;
    public UserUpdater(User user) {
      this.user = user;
    }
    @Override
    public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
      PreparedStatement ps = connection.prepareStatement(
            "UPDATE user SET name=?, email=?, date_of_birth=?, active=? WHERE user_id=?");
      ps.setString(1, user.getName());
      ps.setString(2, user.getEmail());
      ps.setDate(3, new java.sql.Date(user.getDateOfBirth().getTime()));
      ps.setBoolean(4, user.getActive());
      ps.setInt(5, user.getUserId());
      return ps;
    }
  }
  private class UserExtractor implements RowMapper<User> {
    @Override
    public User mapRow(ResultSet rs, int i) throws SQLException {
      User u = new User();
      u.setUserId(rs.getInt("user_id"));
      u.setName(rs.getString("name"));
      u.setEmail(rs.getString("email"));
      u.setDateOfBirth(rs.getDate("date_of_birth"));
      u.setActive(rs.getBoolean("active"));
      return u;
    }
  }
  @Override
  public List<UserCars> getUserCars() {
    return jdbcTemplate.query("SELECT * FROM user_cars", new UserCarsExtractor());
  }
  @Override
  public void createUserCars(UserCars usercars) {
    KeyHolder keyHolder = new GeneratedKeyHolder();
    jdbcTemplate.update(new UserCarsCreator(usercars), keyHolder);
    usercars.setUsercarId(keyHolder.getKey().intValue());
  }
  @Override
  public void updateUserCars(UserCars usercars) {
    jdbcTemplate.update(new UserCarsUpdater(usercars));
  }
  @Override
  public UserCars getUserCarsById(int usercarId) {
    Map namedParameters = Collections.singletonMap("usercarId", usercarId);
    return namedJdbcTemplate.queryForObject("SELECT * FROM user_cars WHERE usercar_id=:usercarId", namedParameters, new UserCarsExtractor());
  }
  private class UserCarsCreator implements PreparedStatementCreator {
    private UserCars usercars;
    public UserCarsCreator(UserCars usercars) {
      this.usercars = usercars;
    }
    @Override
    public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
      PreparedStatement ps = connection.prepareStatement(
            "INSERT INTO user_cars (user_id, car_id, license_plate, kilometers) "
      + "VALUES (?, ?, ?, ?) ", Statement.RETURN_GENERATED_KEYS);
      ps.setInt(1, usercars.getUserId());
      ps.setInt(2, usercars.getCarId());
      ps.setString(3, usercars.getLicensePlate());
      return ps;
    }
  }
  private class UserCarsUpdater implements PreparedStatementCreator {
    private UserCars usercars;
    public UserCarsUpdater(UserCars usercars) {
      this.usercars = usercars;
    }
    @Override
    public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
      PreparedStatement ps = connection.prepareStatement(
            "UPDATE user_cars SET user_id=?, car_id=?, license_plate=?, kilometers=? WHERE usercar_id=?");
      ps.setInt(1, usercars.getUserId());
      ps.setInt(2, usercars.getCarId());
      ps.setString(3, usercars.getLicensePlate());
      ps.setLong(4, usercars.getKilometers());
      ps.setInt(5, usercars.getUsercarId());
      return ps;
    }
  }
  private class UserCarsExtractor implements RowMapper<UserCars> {
    @Override
    public UserCars mapRow(ResultSet rs, int i) throws SQLException {
      UserCars u = new UserCars();
      u.setUsercarId(rs.getInt("usercar_id"));
      u.setUserId(rs.getInt("user_id"));
      u.setCarId(rs.getInt("car_id"));
      u.setLicensePlate(rs.getString("license_plate"));
      u.setKilometers(rs.getLong("kilometers"));
      return u;
    }
  }
}
